# TEST CASES – EVD SYS API

Tài liệu này được lập theo đúng source `evd-sys-api` đã gửi, không phải danh sách API chung chung.

## 1. Chuẩn bị

1. Khởi động PostgreSQL và API theo `README.md`.
2. Base URL mặc định: `http://localhost:8081`.
3. Tài khoản seed:
   - ADMIN: `admin / password`
   - STAFF: `staff / password`
4. Để dữ liệu sạch trước khi chạy toàn bộ case:

```cmd
docker compose down -v
docker compose up -d
```

5. Import hai file vào Postman:
   - `EVD-SYS-API.postman_collection.json`
   - `EVD-SYS-Local.postman_environment.json`
6. Chạy các folder theo thứ tự từ `00` đến `07`.

## 2. Quy ước kết quả lỗi

Các exception đã được `GlobalExceptionHandler` xử lý có cấu trúc:

```json
{
  "timestamp": "2026-07-11T00:00:00Z",
  "status": 400,
  "error": "VALIDATION_ERROR",
  "message": "Validation failed",
  "fieldErrors": {
    "username": "Username is required"
  }
}
```

Các lỗi do Spring Security hoặc lỗi chưa được custom có thể không theo cấu trúc này.

## 3. Danh sách test case

| ID | Chức năng | Tình huống / dữ liệu | Kết quả mong đợi |
|---|---|---|---|
| AUTH-01 | Login | `admin/password` | `200`; có `accessToken`, `tokenType=Bearer`, `expiresInSeconds=7200` theo cấu hình mặc định |
| AUTH-02 | Login | `staff/password` | `200`; có JWT |
| AUTH-03 | Login | Sai mật khẩu | `401`; `error=UNAUTHORIZED` |
| AUTH-04 | Login | Username không tồn tại | `401`; không tiết lộ username hay password sai |
| AUTH-05 | Login validation | Username và password rỗng | `400`; có lỗi cho cả hai field |
| AUTH-06 | Login validation | Username dài hơn 50 ký tự | `400` |
| AUTH-07 | Login validation | Password dài hơn 72 ký tự | `400` |
| AUTH-08 | JWT | Gọi API bảo vệ không có token | Bị chặn; source hiện tại có thể trả `403`, REST chuẩn thường mong `401` |
| AUTH-09 | JWT | Token giả, sai chữ ký hoặc malformed | Bị chặn; source hiện tại có thể trả `403` |
| USR-01 | User list | ADMIN gọi `GET /api/users` | `200`; có `admin` và `staff`; response không chứa password |
| USR-02 | Authorization | STAFF gọi `GET /api/users` | `403` |
| USR-03 | Create user | ADMIN tạo username mới, password >= 8, role STAFF | `201`; có header `Location`; password được ẩn |
| USR-04 | Duplicate user | Tạo lại username đã tồn tại | `409`; `DUPLICATE_RESOURCE` |
| USR-05 | Create validation | Username ngắn hơn 3 | `400` |
| USR-06 | Create validation | Password ngắn hơn 8 | `400` |
| USR-07 | Create validation | Thiếu role | `400` |
| USR-08 | Create validation | Role ngoài `ADMIN/STAFF` | `400`; body có thể là lỗi mặc định vì enum parse chưa custom |
| USR-09 | Get user | ID tồn tại | `200`; đúng id, username, role, createdAt |
| USR-10 | Get user | ID không tồn tại | `404`; `NOT_FOUND` |
| USR-11 | Update user | Đổi password, giữ username và role | `200`; password cũ đăng nhập thất bại, password mới thành công |
| USR-12 | Update user | Omit `password` hoặc truyền `null` | `200`; không đổi password |
| USR-13 | Update duplicate | Đổi username sang username đã có | `409` |
| USR-14 | Update validation | Username rỗng hoặc role null | `400` |
| USR-15 | Delete user | User không có document | `204`; GET lại trả `404` |
| USR-16 | Delete user | User đang sở hữu document | Source hiện tại có nguy cơ `500` do khóa ngoại; nên xử lý thành `409` hoặc chặn có message rõ ràng |
| USR-17 | Authorization | STAFF gọi POST/PUT/DELETE user | `403` |
| DOC-01 | Create document | ADMIN tạo DRAFT hợp lệ | `201`; `createdByUsername=admin` |
| DOC-02 | Create document | STAFF tạo SUBMITTED hợp lệ | `201`; owner là staff hiện tại |
| DOC-03 | Create document | STAFF2 tạo APPROVED hợp lệ | `201`; owner là STAFF2 |
| DOC-04 | Duplicate code | Tạo code đã tồn tại | `409`; code là duy nhất toàn hệ thống |
| DOC-05 | Create validation | Code rỗng | `400` |
| DOC-06 | Create validation | Title rỗng hoặc >255 | `400` |
| DOC-07 | Create validation | Description >2000 | `400` |
| DOC-08 | Create validation | Category rỗng hoặc >100 | `400` |
| DOC-09 | Create validation | Status null | `400` |
| DOC-10 | Enum validation | Status=`PENDING` | `400`; body có thể không theo `ApiError` |
| DOC-11 | View authorization | STAFF xem document của mình | `200` |
| DOC-12 | View authorization | STAFF xem document của ADMIN/STAFF khác | `403`; `FORBIDDEN` |
| DOC-13 | View authorization | ADMIN xem document của mọi user | `200` |
| DOC-14 | Get document | ID không tồn tại | `404` |
| DOC-15 | Update document | STAFF cập nhật document của mình | `200`; title/category/status đổi; code và owner không đổi |
| DOC-16 | Update authorization | STAFF cập nhật document người khác | `403` |
| DOC-17 | Update authorization | ADMIN cập nhật document STAFF | `200` |
| DOC-18 | Delete authorization | STAFF xóa document của mình | `403`; chỉ ADMIN được xóa |
| DOC-19 | Delete document | ADMIN xóa document tồn tại | `204`; GET lại `404` |
| DOC-20 | Delete document | ADMIN xóa ID không tồn tại | `404` |
| LIST-01 | Pagination | Không truyền query param | `200`; page=0, size=10, sort=`createdAt,desc` |
| LIST-02 | Pagination | `page=0&size=1` | Tối đa 1 phần tử, metadata đúng |
| LIST-03 | Pagination validation | `page=-1` | `400`; `Page must be greater than or equal to 0` |
| LIST-04 | Pagination validation | `size=0` | `400` |
| LIST-05 | Pagination validation | `size=101` | `400` |
| LIST-06 | Filter status | `status=REJECTED` | Tất cả phần tử trả về có status REJECTED |
| LIST-07 | Filter category | `category=hr` | Match category HR không phân biệt hoa thường |
| LIST-08 | Search | `keyword=contract` | Search không phân biệt hoa thường trên `title` hoặc `code` |
| LIST-09 | Combined filters | status + category + keyword | Mỗi phần tử thỏa tất cả điều kiện |
| LIST-10 | Sort | `sort=title,asc` | Danh sách tăng dần theo title |
| LIST-11 | Sort | `sort=createdAt,desc` | Danh sách giảm dần theo createdAt |
| LIST-12 | Sort validation | Field ngoài whitelist | `400`; `Unsupported sort field` |
| LIST-13 | Sort validation | Direction ngoài asc/desc | `400` |
| LIST-14 | Page vượt giới hạn | Page rất lớn | `200`; `content=[]` |
| LIST-15 | Ownership list | STAFF list không filter | Chỉ có document do chính STAFF đó tạo |
| LIST-16 | Admin list | ADMIN list | Có thể thấy document của tất cả user |
| REP-01 | Aggregate JDBC | ADMIN gọi count-by-status | `200`; mỗi item có `status`, `total`; total đúng với DB |
| REP-02 | Report authorization | STAFF gọi report | `403` |
| REP-03 | Aggregate accuracy | Tạo DRAFT/SUBMITTED/REJECTED rồi gọi report | Count tăng tương ứng; đối chiếu bằng SQL `GROUP BY status` |
| FILE-01 | Upload | Owner upload file <=10MB | `200`; `fileName` là UUID và giữ extension |
| FILE-02 | Upload authorization | STAFF upload vào document người khác | `403` |
| FILE-03 | Upload | Thiếu multipart part `file` | `400` |
| FILE-04 | Upload | File rỗng | Source hiện tại có nguy cơ `500`; nên map thành `400` |
| FILE-05 | Upload | File >10MB | Mong đợi `413 Payload Too Large` |
| FILE-06 | Upload security | Filename chứa `..` | Bị từ chối; source hiện tại có nguy cơ `500`, nên là `400` |
| FILE-07 | Upload | File không có extension | `200`; tên lưu là UUID không extension |
| FILE-08 | Upload replace | Upload file lần hai cùng document | `fileName` đổi; cần kiểm tra file cũ có còn tồn tại vì source chưa xóa file cũ |

## 4. SQL đối chiếu nhanh

```sql
SELECT id, username, role, created_at
FROM users
ORDER BY id;

SELECT id, code, title, category, status, created_by, file_name
FROM documents
ORDER BY id;

SELECT status, COUNT(*) AS total
FROM documents
GROUP BY status
ORDER BY status;
```

## 5. Các điểm dễ bị nhà tuyển dụng hỏi sau khi test

1. Vì sao request không token đang có thể trả `403` thay vì `401`?
   - Chưa cấu hình custom `AuthenticationEntryPoint`.

2. Vì sao lỗi STAFF truy cập user management không có cùng format `ApiError`?
   - Đây là lỗi do Spring Security/Method Security, không đi qua các handler nghiệp vụ hiện tại theo cùng cách.

3. Vì sao xóa user có document có thể thành `500`?
   - Bảng `documents.created_by` có foreign key, trong khi service chưa kiểm tra và chưa bắt `DataIntegrityViolationException`.

4. Vì sao file rỗng hoặc filename không hợp lệ có thể thành `500`?
   - `FileStorageService` ném `IllegalArgumentException`, nhưng `GlobalExceptionHandler` chưa có handler tương ứng.

5. JWT có claim `role`, nhưng filter đang load lại user từ DB và lấy authority hiện tại.
   - Quyền thay đổi trong DB có hiệu lực ở request sau; claim role không phải nguồn quyền cuối cùng trong flow hiện tại.

## 6. Tiêu chí pass bài test

- ADMIN thực hiện được toàn bộ user CRUD và document CRUD.
- STAFF chỉ tạo, xem, sửa document của mình; không xóa; không quản lý user/report.
- List hỗ trợ pagination, status/category, title/code search và whitelist sorting.
- Report dùng JDBC và số liệu đúng.
- Validation và HTTP status rõ ràng.
- File upload hoạt động trong giới hạn 10MB.
- Không trả password trong response.
- Test cleanup hoàn tất để có thể chạy lại.
