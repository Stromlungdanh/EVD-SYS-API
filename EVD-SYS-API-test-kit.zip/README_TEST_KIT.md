# EVD SYS API Test Kit

## File trong bộ test

- `TEST_CASES.md`: danh sách test case theo source.
- `EVD-SYS-API.postman_collection.json`: collection có script lưu token/id tự động.
- `EVD-SYS-Local.postman_environment.json`: environment local.
- `sample-upload.txt`: file mẫu để test upload.

## Cách chạy nhanh

1. Start source ở `http://localhost:8081`.
2. Import collection và environment vào Postman.
3. Chọn environment `EVD SYS - Local`.
4. Chạy folder theo thứ tự `00` → `07`.
5. Folder upload file cần mở request và chọn file thủ công.
